import wx
import wx.grid
import pandas as pd

from grid_template import MyFrame2 as MyFrame1

EVEN_ROW_COLOUR = '#CCE6FF'
GRID_LINE_COLOUR = '#ccc'

# df = pd.read_csv(r".\PartGlobalWeatherRepository.csv")
df = pd.read_csv(r"..\winereviews.csv",index_col=0)

class DataTable(wx.grid.GridTableBase):
    def __init__(self, data=None):
        wx.grid.GridTableBase.__init__(self)
        self.headerRows = 1
        self.data = data

    def GetNumberRows(self):
        return len(self.data.index)

    def GetNumberCols(self):
        return len(self.data.columns)

    def GetValue(self, row, col):
        return self.data.iloc[row, col]

    def SetValue(self, row, col, value):
        self.data.iloc[row, col] = value

    # For better visualisation
    def GetColLabelValue(self, col):
        return self.data.columns[col]

    def GetAttr(self, row, col, prop):
        attr = wx.grid.GridCellAttr()
        if row % 2 == 1:
            attr.SetBackgroundColour(EVEN_ROW_COLOUR)
        return attr


class CalcFrame(MyFrame1):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.table = DataTable(df)

        self.m_grid2.SetTable(self.table, takeOwnership=True)
        self.m_grid2.AutoSize()

        self.Show(True)
        self.Layout()

    def OnSearch( self, event ):
        min_temp = float(self.m_textCtrl2.GetValue())
        df_1 = df[df['points'] > min_temp]

        max_temp = float(self.m_textCtrl3.GetValue())
        df_1 = df_1[df_1['points'] < max_temp]

        tabel = DataTable(df_1)
        self.m_grid2.ClearGrid()
        self.m_grid2.SetTable(tabel,True)
        self.m_grid2.AutoSize()
        self.Layout()


if __name__ == "__main__":

    app = wx.App(False)
    frame = CalcFrame()
    app.MainLoop()