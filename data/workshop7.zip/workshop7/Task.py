import pandas as pd
import re

# to set some options to better print pandas data
pd.set_option('display.max_columns', 20)
pd.set_option('display.max_colwidth', 20)
pd.set_option('display.expand_frame_repr', False)

reviews = pd.read_csv(r".\winereviews.csv", index_col=0)

""" What countries are represented in the dataset? (Your answer should not include
any duplicates.)"""

countries = reviews['country'].unique()
print(countries)
print()

""" Show all wines with a score of 100"""
pointsover100 = reviews[reviews["points"] == 100]
print(pointsover100)
print()

"""Show all wines with a cost of over 1000"""
priceover1000 = reviews[reviews["price"] >= 1000]
print(priceover1000)
print()

"""Find the highest rated wine for each variety"""
# show groupby result
# review_by_variety = reviews.groupby("variety")
# review_by_variety.apply(print)

# highestVariety = reviews["points"].groupby(reviews["variety"]).max()
highestVariety = reviews.groupby("variety")["points"].max()
print(highestVariety)
print()

"""Find the lowest rated wine for each variety"""
# lowestVariety = reviews["points"].groupby(reviews["variety"]).min()
lowestVariety = reviews.groupby("variety")["points"].min()
print(lowestVariety)
print()

"""Find the top 10 bargain wines (wines with the highest points-to-price ratio)"""
bargains = reviews
bargains['Value'] = bargains.points / bargains.price
print(bargains.nlargest(10, 'Value'))
print()

"""
Calculate the average price of wine for each:
      Country
      Variety
"""
averageCountryPrice = reviews.groupby("country")["price"].mean()
print(averageCountryPrice)
print()

averageVarietyPrice = reviews.groupby("variety")["price"].mean()
print(averageVarietyPrice)
print()

"""
Calculate the average score for wine for each:
    Country
    Variety
"""
averageCountryScore = reviews.groupby("country")["points"].mean()
print(averageCountryScore)
print()

averageVarietyScore = reviews.groupby("variety")["points"].mean()
print(averageVarietyScore)
print()

"""
What combination of countries and varieties are most common? Create a Series whose index is
a MultiIndex of {country, variety} pairs. For example, a pinot noir produced in the US should map
to {"US", "Pinot Noir"}. Sort the values in the Series in descending order based on wine count.
"""
country_variety_counts = reviews.groupby(['country', 'variety'])['variety'].count().sort_values(ascending=False)
print(country_variety_counts)
print()

"""

There are only so many words you can use when describing a bottle of wine. Is a wine more
likely to be "tropical" or "fruity"? Go through all the review descriptions (use pandas to turn them
into a series) and find reviews that use the term ‘tropical’ or ‘fruity’. Use Regular expressions to
do the text matching. Count the number of reviews for each word.

"""

descs = reviews["description"]
fruity = 0
tropical = 0
for d in descs:
    if (re.search("fruity", d)):
        fruity += 1
    if (re.search("tropical", d)):
        tropical += 1

print("Tropical/Fruity with Regular Expressions")
print("Tropical:", tropical)
print("Fruity:", fruity)

n_trop = reviews.description.map(lambda desc: "tropical" in desc).sum()
n_fruity = reviews.description.map(lambda desc: "fruity" in desc).sum()
print("Tropical/Fruity with Pandas")
print("Tropical:", n_trop)
print("Fruity:", n_fruity)
