import openpyxl


if __name__ == "__main__":
    wb = openpyxl.load_workbook(r'.\stocks.xlsx')
    print(wb.sheetnames)
    ws = wb['IBM']

    # print all info in IBM
    for row in ws.iter_rows():
        for cell in row:
            print(cell.value, end=' ')
        print()

    # print all info in 2010 in IBM
    for row in ws.iter_rows():
        date = row[0].value
        if date.year == 2010:
            for cell in row:
                print(cell.value, end=' ')
            print()


    # get all the price in 2010 in IBM, print min, max, and mean
    tData = []
    for row in ws.iter_rows():
        date = row[0].value
        price = row[3].value
        if (date.year == 2010):
            tData.append(price)

    print("2010 Min: ", min(tData))
    print("2010 Max: ", max(tData))
    print("2010 Avg: ", sum(tData) / len(tData))