import sqlite3

def printRes(r):
    for l in r:
        print(l)
    print()


if __name__ == "__main__":
    connection = sqlite3.connect(r".\hotel.db")
    cursor = connection.cursor()

    sql_cmd = """
    SELECT name FROM sqlite_master WHERE type='table';
    """
    cursor.execute(sql_cmd)
    res = cursor.fetchall()
    print(res)

    for table_info in res:
        table_name = table_info[0]
        sql_cmd = f"""
        SELECT * FROM {table_name}
        """
        cursor.execute(sql_cmd)
        column_names = sqlite3.Row(cursor,(1,)).keys()
        print(f'{table_name}: {column_names}')
    print()

    sql_cmd = """
    SELECT * FROM Hotel WHERE city = 'Brisbane';
    """
    cursor.execute(sql_cmd)
    res = cursor.fetchall()
    printRes(res)

    sql_cmd = """
    SELECT guestName, guestAddress FROM Guest ORDER BY guestName;
    """
    cursor.execute(sql_cmd)
    res = cursor.fetchall()
    printRes(res)

    sql_cmd = """
    SELECT price, roomtype FROM Room, Hotel where Room.hotelNo = Hotel.hotelNo and Hotel.hotelName = 'Grosvenor Hotel';
    """
    cursor.execute(sql_cmd)
    res = cursor.fetchall()
    printRes(res)

    sql_cmd = """
    SELECT MIN(price), MAX(price), AVG(price) FROM Room;
    """
    cursor.execute(sql_cmd)
    res = cursor.fetchall()
    printRes(res)
